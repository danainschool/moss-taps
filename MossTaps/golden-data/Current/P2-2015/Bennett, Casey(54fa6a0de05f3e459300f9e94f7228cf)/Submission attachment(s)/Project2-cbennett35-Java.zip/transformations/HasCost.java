package ravensproject.transformations;

public interface HasCost {
    int getCost();
}
