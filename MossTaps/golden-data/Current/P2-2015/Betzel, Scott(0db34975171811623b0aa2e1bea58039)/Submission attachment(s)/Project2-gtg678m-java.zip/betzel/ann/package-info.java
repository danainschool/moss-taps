/**
 * This package contains code the will be used to
 * implement a MultiLayerNeuralNetwork.
 */
package ravensproject.betzel.ann;
