package ravensproject.betzel.agents;

import ravensproject.RavensProblem;

import java.util.*;

/**
 * Created by scott betzel on 6/23/15.
 *
 *
 */
public class FrameDifferenceAgent
    extends AgentBase {

    public FrameDifferenceAgent(String theName) {
        super(theName);

    }

    @Override
    public Set<Integer> solve(RavensProblem problem) throws Exception {
        return null;
    }



}
