package ravensproject.betzel.interfaces;

/**
 * Created by scott betzel on 6/4/15.
 */
public interface ISolver {
    int solve();
}
