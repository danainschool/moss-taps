package ravensproject;

public interface ISlot {
	public Change Compare(ISlot slot);
}
