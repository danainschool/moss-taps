package ravensproject;

public enum Change {

	NotUsed,
	Unchanged,
	Reflected,
	Rotated,
	Scaled,
	Deleted,
	Changed
}
